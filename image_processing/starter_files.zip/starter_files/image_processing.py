from PIL import Image
from copy import deepcopy
import sys
import numpy as np


# You do not need to change the following function. It can be used to open images.
def open_image(filename):
    im = Image.open(filename) # open image
    data = np.array(im) # convert image to a 2D array of colors
    return data

# You do not need to change the following function. It can be used to save images.
def save_image(image_data, filename):
	img = Image.fromarray(image_data, 'RGB') # convert new image data to an image
	img.save(filename) # write the image to disk




'''
TODO: create your own filter based on the one below.
'''

def my_filter(image_data):
    '''A deep copy is a copy of data in memory, not just a copy
       of the reference to the data'''
    result = deepcopy(image_data) # create a deep copy
    for row in range(0, len(image_data)): # loop over each row in the image
        for col in range(0, len(image_data[row])):  # loop over each column in a given row
            result[row][col][0] = image_data[row][col][0]   # keep the red value
            result[row][col][1] = image_data[row][col][1]*0 # zero out the green value
            result[row][col][2] = image_data[row][col][2]*0.5 # half the blue value
    return result



'''
Test your filter(s) my modifying the following code.
To run tests, you will need to give the input image file name and output image file name using the command line (i.e., the terminal).
In other words, you will need to run this code like this:
    python image_processing <input file name> <output file name>
For example, if the input file name is "dog.jpeg" and the output file name is "out.jpeg", you run
    python image_processing "dog.jpeg" "out.jpeg"
This would open dog.jpeg, run the filter, and then produce a new file called out.jpeg with the filtered image.
'''
input_filename = sys.argv[1]   # get input image file name from command line
output_filename = sys.argv[2]  # get output image file name from command line

input_image = open_image(input_filename)  # open the input image
new_image = my_filter(input_image)  # Test a filter here. This creates a new image
save_image(new_image, output_filename)    # save the new image



